# Information Retrieval Challenge A

**Status**: Current level to beat: level 1

**Command to try**:

```
pytest -s tests/integration/challenges/information_retrieval/test_information_retrieval_challenge_a.py
```

## Description

The agent's goal is to find the revenue of Tesla in 2022.

It should write the result in a file called output.txt.

The agent should be able to beat this test consistently (this is the hardest part).
## Objective

The objective of this challenge is to test the agent's ability to retrieve information in a consistent way.
