# Python script to analyze Angular code and identify instances of the 'ngOnInit' lifecycle hook

import re

# Regular expression to match ngOnInit
ngOnInit_regex = re.compile(r'ngOnInit')

# Read the Angular code from a file
with open('angular_code.ts', 'r') as f:
    angular_code = f.read()

# Search for instances of ngOnInit in the Angular code
ngOnInit_matches = ngOnInit_regex.findall(angular_code)

# Print the number of matches found
print('Number of ngOnInit matches:', len(ngOnInit_matches))
