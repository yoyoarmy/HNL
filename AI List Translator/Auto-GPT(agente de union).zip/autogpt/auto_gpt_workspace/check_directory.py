import os

path = os.path.join('C:', 'autologous_gpt_workspace')

try:
    files = os.listdir(path)
    print(files)
except FileNotFoundError:
    print(f'Directory {path} does not exist')