import subprocess

subprocess.run(['eslint', '--fix', 'translated_code.js'])
subprocess.run(['prettier', '--write', 'translated_code.js'])