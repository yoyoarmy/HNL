import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SimpleNotificationsModule } from 'angular2-notifications';
import 'angular2-notifications';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// *******************************************************************************
// NgBootstrap

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

// *******************************************************************************
// Libs

import { SweetAlert2Module } from '@toverux/ngx-sweetalert2';
import { ToastrModule } from 'ngx-toastr';
import { ConfirmationPopoverModule } from 'angular-confirmation-popover';
import { ContextMenuModule } from 'ngx-contextmenu';
import { TourNgBootstrapModule } from 'ngx-tour-ng-bootstrap';
// import { AgmCoreModule } from '../vendor/libs/agm/core';
import { AgmCoreModule } from '@agm/core';
import { AgmSnazzyInfoWindowModule } from '@agm/snazzy-info-window';

import { BlockUIModule } from 'ng-block-ui';
import { CalendarModule } from 'angular-calendar';
import { LoadingBarModule } from '@ngx-loading-bar/core';

// *******************************************************************************
// App

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppService } from './app.service';
import { LayoutModule } from './layout/layout.module';
import { ThemeSettingsModule } from '../vendor/libs/theme-settings/theme-settings.module';
import { CoreModule } from './pages/core/core.module';
import { TranslateModule } from '@ngx-translate/core';
import { SettingsProvidersService } from './pages/core/service/settings-providers.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AngularFireMessagingModule } from '@angular/fire/messaging';
import { AngularFireModule } from '@angular/fire';
import { CloudMessagingService } from './pages/core/service/cloudMessaging.service';
import { HttpConfigInterceptor } from './pages/core/interceptors/httpConfig.interceptor';

// *******************************************************************************
//

@NgModule({
  declarations: [AppComponent],

  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    SimpleNotificationsModule.forRoot(),
    NgbModule.forRoot(),
    TranslateModule.forRoot(),
    LoadingBarModule.forRoot(),

    // App
    AppRoutingModule,
    LayoutModule,
    ThemeSettingsModule,

    // Core
    CoreModule,

    // Libs
    SweetAlert2Module.forRoot({
      buttonsStyling: false,
      confirmButtonClass: 'btn btn-lg btn-primary',
      cancelButtonClass: 'btn btn-lg btn-default',
    }),
    ToastrModule.forRoot({
      tapToDismiss: true,
      closeButton: true,
      progressBar: true,
      progressAnimation: 'increasing',
      positionClass: 'toast-top-right',
      preventDuplicates: true,
      newestOnTop: true,
    }),
    ConfirmationPopoverModule.forRoot({
      cancelButtonType: 'default btn-sm',
      confirmButtonType: 'primary btn-sm',
    }),
    ContextMenuModule.forRoot(),
    TourNgBootstrapModule.forRoot(),
    AgmCoreModule.forRoot({
      /* NOTE: When using Google Maps on your own site you MUST get your own API key:
               https://developers.google.com/maps/documentation/javascript/get-api-key
               After you got the key paste it in the URL below. */
      apiKey: 'AIzaSyAeBDp4D2wlpI3qhOvNeXZwDPoVh2CybTE',
      libraries: ['geometry'],
    }),
    AgmSnazzyInfoWindowModule,
    BlockUIModule.forRoot(),
    CalendarModule.forRoot(),

    //Cloud Messaging Firebase
    AngularFireMessagingModule,
    AngularFireModule.initializeApp({
      apiKey: 'AIzaSyC78Jwr5AWaWyN4UnBK-cs-fsT9ZqM2LXc',
      messagingSenderId: '1002325262041',
    }),
  ],

  providers: [
    SettingsProvidersService,

    {
      provide: APP_INITIALIZER,
      useFactory: init,
      deps: [SettingsProvidersService, AppService],
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpConfigInterceptor,
      multi: true,
    },
    Title,
    AppService,
    CloudMessagingService,
  ],

  bootstrap: [AppComponent],
})
export class AppModule {}

export function init(settings: SettingsProvidersService) {
  return () => {
    return settings.loadConfig();
  };
}
